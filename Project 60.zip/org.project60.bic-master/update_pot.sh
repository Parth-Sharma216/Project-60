#!/bin/sh

l10n_tools="../civi_l10n_tools"

${l10n_tools}/bin/create-pot-files-extensions.sh org.project60.bic ./ l10n
